// Optimized CheckList Structure for Score Calculation and Parsing
const checkList = [
  {
    id: "01",
    departement: "DPAL",
    niveau: 6,
    title: "Site Communautaire",
    maxScore: 37,
    sections: [
      {
        id: "section_01_01",
        title: "Ressources humaines",
        maxScore: 11,
        subsections: [
          {
            id: "subsection_01_01_01",
            title: "Le Site communautaire dispose-t-elle d'un :",
            maxScore: 11,
            questions: [
              {
                id: "rh_001",
                text: "Agent communautaire formé aux protocoles de prise en charge du paludisme",
                type: "simple",
                maxScore: 1,
                required: true
              },
              {
                id: "rh_002", 
                text: "AC formé en test de diagnostic rapide du paludisme",
                type: "simple",
                maxScore: 1,
                required: true
              },
              {
                id: "rh_003",
                text: "AC formé sur la communication dans la lutte contre paludisme",
                type: "simple", 
                maxScore: 1,
                required: true
              },
              {
                id: "rh_004",
                text: "Est-ce que l'AC est en possession des documents cadres",
                type: "multiple",
                maxScore: 3,
                required: true,
                subQuestions: [
                  {
                    id: "rh_004_a",
                    text: "Ordonnogramme PEC",
                    maxScore: 1
                  },
                  {
                    id: "rh_004_b", 
                    text: "Job Aids",
                    maxScore: 1
                  },
                  {
                    id: "rh_004_c",
                    text: "Affiches",
                    maxScore: 1
                  }
                ]
              },
              {
                id: "rh_005",
                text: "Est-ce que l'AC est doté de matériels",
                type: "multiple",
                maxScore: 3,
                required: true,
                subQuestions: [
                  {
                    id: "rh_005_a",
                    text: "Tablette",
                    maxScore: 1
                  },
                  {
                    id: "rh_005_b",
                    text: "Connexion internet", 
                    maxScore: 1
                  },
                  {
                    id: "rh_005_c",
                    text: "Crédit de communication",
                    maxScore: 1
                  }
                ]
              },
              {
                id: "rh_006",
                text: "Est-ce que l'AC est encadré et supervisé par le Chef CSB et/ou AC relais",
                type: "simple",
                maxScore: 1,
                required: true
              },
              {
                id: "rh_007",
                text: "Est-ce que l'AC participe à la revue mensuelle au niveau CSB",
                type: "simple",
                maxScore: 1,
                required: true
              },
              {
                id: "rh_008",
                text: "Est-ce que l'AC relais fait des supervisions des AC",
                type: "multiple",
                maxScore: 2,
                required: true,
                subQuestions: [
                  {
                    id: "rh_008_a",
                    text: "Planning de supervision",
                    maxScore: 1
                  },
                  {
                    id: "rh_008_b",
                    text: "Rapport de supervision", 
                    maxScore: 1
                  }
                ]
              }
            ]
          }
        ]
      },
      {
        id: "section_01_02",
        title: "Prévention",
        maxScore: 26,
        subsections: [
          {
            id: "subsection_01_02_01",
            title: "Utilisation MII",
            maxScore: 9,
            categories: [
              {
                id: "category_01_02_01_01",
                name: "Accès et réception",
                maxScore: 3,
                questions: [
                  {
                    id: "mii_001",
                    text: "Avez-vous reçu des MII lors de la dernière distribution (campagne, routine ou urgence) ? Si oui, combien de MII?",
                    type: "simple",
                    maxScore: 1,
                    required: true
                  },
                  {
                    id: "mii_002",
                    text: "Les MII que vous avez reçues ont-elles été distribuées gratuitement ? Si non, combien avez-vous payé ?",
                    type: "simple",
                    maxScore: 1,
                    required: true
                  },
                  {
                    id: "mii_003",
                    text: "Utilisez-vous régulièrement votre MII pour dormir la nuit?",
                    type: "simple",
                    maxScore: 1,
                    required: true
                  }
                ]
              },
              {
                id: "category_01_02_01_02",
                name: "Qualité et utilisation",
                maxScore: 1,
                questions: [
                  {
                    id: "mii_004",
                    text: "Votre moustiquaire est-elle actuellement en bon état (pas de trou, propre, bien suspendue) ?",
                    type: "simple",
                    maxScore: 1,
                    required: true
                  }
                ]
              },
              {
                id: "category_01_02_01_03",
                name: "Sensibilisation et information",
                maxScore: 3,
                questions: [
                  {
                    id: "mii_005",
                    text: "Lors de la distribution, les agents communautaires vous ont-ils expliqué comment entretenir la MII ?",
                    type: "simple",
                    maxScore: 1,
                    required: true
                  },
                  {
                    id: "mii_006",
                    text: "Avez-vous été informé par un agent communautaire sur la première utilisation des MII (ex. : aération avant usage) ?",
                    type: "simple",
                    maxScore: 1,
                    required: true
                  },
                  {
                    id: "mii_007",
                    text: "Avez-vous reçu des informations sur l'entretien des MII (lavage, séchage, etc.) ? Si oui, par qui ?",
                    type: "simple",
                    maxScore: 1,
                    required: true
                  }
                ]
              },
              {
                id: "category_01_02_01_04",
                name: "Observations communautaires",
                maxScore: 2,
                questions: [
                  {
                    id: "mii_008",
                    text: "Avez-vous observé des problèmes lors de la distribution ou dans l'utilisation des MII dans votre communauté ? Si oui, précisez",
                    type: "simple",
                    maxScore: 1,
                    required: true
                  },
                  {
                    id: "mii_009",
                    text: "Les membres de votre communauté utilisent-ils correctement les MII selon vous ?",
                    type: "simple",
                    maxScore: 1,
                    required: true
                  }
                ]
              }
            ]
          },
          {
            id: "subsection_01_02_02",
            title: "Application GIV",
            maxScore: 3,
            questions: [
              {
                id: "giv_001",
                text: "L'AC effectue-t-il des activités de sensibilisation au niveau de sa localité sur la nécessité de réalisation périodique du GIV",
                type: "simple",
                maxScore: 1,
                required: true
              },
              {
                id: "giv_002",
                text: "L'AS est-il en mesure d'expliquer à la communauté ce qu'est la GIV et quels sont les activités à réaliser au cours de la GIV",
                type: "simple",
                maxScore: 1,
                required: true
              },
              {
                id: "giv_003",
                text: "L'ASC est-il en mesure de convaincre sa communauté de réaliser la GIV de façon périodique",
                type: "simple",
                maxScore: 1,
                required: true
              }
            ]
          },
          {
            id: "subsection_01_02_03",
            title: "Pulvérisation intra-domicilaire",
            maxScore: 7,
            categories: [
              {
                id: "category_01_02_03_01",
                name: "Agents pulvérisateurs",
                maxScore: 3,
                questions: [
                  {
                    id: "pulv_001",
                    text: "Avez-vous reçu une formation ? Si oui, sur quoi ?",
                    type: "simple",
                    maxScore: 1,
                    required: true
                  },
                  {
                    id: "pulv_002",
                    text: "Combien de maisons pulvérisez-vous par jour en moyenne ?",
                    type: "simple",
                    maxScore: 1,
                    required: true
                  },
                  {
                    id: "pulv_003",
                    text: "Rencontrez-vous des difficultés spécifiques ?",
                    type: "simple",
                    maxScore: 1,
                    required: true
                  }
                ]
              },
              {
                id: "category_01_02_03_02",
                name: "Ménages",
                maxScore: 4,
                questions: [
                  {
                    id: "pulv_004",
                    text: "Avez-vous été informé avant la pulvérisation ?",
                    type: "simple",
                    maxScore: 1,
                    required: true
                  },
                  {
                    id: "pulv_005",
                    text: "Les agents ont-ils expliqué les consignes à suivre ?",
                    type: "simple",
                    maxScore: 1,
                    required: true
                  },
                  {
                    id: "pulv_006",
                    text: "Avez-vous accepté la pulvérisation ? Si non, pourquoi ?",
                    type: "simple",
                    maxScore: 1,
                    required: true
                  },
                  {
                    id: "pulv_007",
                    text: "Y a-t-il eu des effets secondaires après la pulvérisation ?",
                    type: "simple",
                    maxScore: 1,
                    required: true
                  }
                ]
              }
            ]
          },
          {
            id: "subsection_01_02_04",
            title: "TPI pour les femmes enceintes",
            maxScore: 8,
            questions: [
              {
                id: "tpi_001",
                text: "Les SP sont disponibles dans le centre et en quantité suffisante au niveau du site",
                type: "simple",
                maxScore: 1,
                required: true
              },
              {
                id: "tpi_002",
                text: "L'agent communautaire/relais a été formé à l'administration du TPIg",
                type: "simple",
                maxScore: 1,
                required: true
              },
              {
                id: "tpi_003",
                text: "Le TPIg est administré sous observation directe (DOT) même en communauté",
                type: "simple",
                maxScore: 1,
                required: true
              },
              {
                id: "tpi_004",
                text: "Un délai d'au moins 1 mois entre deux doses est respecté",
                type: "simple",
                maxScore: 1,
                required: true
              },
              {
                id: "tpi_005",
                text: "Les SP sont administrés à partir du 2è trimestre de grossesse",
                type: "simple",
                maxScore: 1,
                required: true
              },
              {
                id: "tpi_006",
                text: "L'AC/relais conseille la femme enceinte sur les effets secondaires, les bénéfices, et le suivi à faire",
                type: "simple",
                maxScore: 1,
                required: true
              },
              {
                id: "tpi_007",
                text: "Les femmes enceintes sont référées au centre de santé pour la 1re consultation CPN ou en cas de signes d'alerte",
                type: "simple",
                maxScore: 1,
                required: true
              },
              {
                id: "tpi_008",
                text: "Le site communautaire est doté de supports d'éducation (affiches, flyers, audio, etc.)",
                type: "simple",
                maxScore: 1,
                required: true
              }
            ]
          }
        ]
      }
    ]
  }
];

// Utility functions for score calculation and parsing
export const ScoreCalculator = {
  // Calculate score for a single question
  calculateQuestionScore: (question, responses) => {
    const response = responses[question.id];
    if (!response) return 0;
    
    if (question.type === "simple") {
      return response === true ? question.maxScore : 0;
    } else if (question.type === "multiple") {
      return question.subQuestions.reduce((total, subQ) => {
        const subResponse = response[subQ.id];
        return total + (subResponse === true ? subQ.maxScore : 0);
      }, 0);
    }
    return 0;
  },

  // Calculate score for a section
  calculateSectionScore: (section, responses) => {
    let totalScore = 0;
    
    if (section.questions) {
      totalScore += section.questions.reduce((sum, question) => {
        return sum + ScoreCalculator.calculateQuestionScore(question, responses);
      }, 0);
    }
    
    if (section.subsections) {
      totalScore += section.subsections.reduce((sum, subsection) => {
        return sum + ScoreCalculator.calculateSectionScore(subsection, responses);
      }, 0);
    }
    
    if (section.categories) {
      totalScore += section.categories.reduce((sum, category) => {
        return sum + ScoreCalculator.calculateSectionScore(category, responses);
      }, 0);
    }
    
    return totalScore;
  },

  // Calculate total score for entire assessment
  calculateTotalScore: (assessment, responses) => {
    return assessment.sections.reduce((total, section) => {
      return total + ScoreCalculator.calculateSectionScore(section, responses);
    }, 0);
  },

  // Calculate percentage score
  calculatePercentageScore: (assessment, responses) => {
    const totalScore = ScoreCalculator.calculateTotalScore(assessment, responses);
    return Math.round((totalScore / assessment.maxScore) * 100);
  }
};

// Parser utilities for extracting questions
export const QuestionParser = {
  // Extract all questions from assessment with their paths
  extractAllQuestions: (assessment) => {
    const questions = [];
    
    const extractFromSection = (section, path = []) => {
      const currentPath = [...path, section.id];
      
      if (section.questions) {
        section.questions.forEach(question => {
          questions.push({
            ...question,
            path: currentPath,
            sectionTitle: section.title
          });
        });
      }
      
      if (section.subsections) {
        section.subsections.forEach(subsection => {
          extractFromSection(subsection, currentPath);
        });
      }
      
      if (section.categories) {
        section.categories.forEach(category => {
          extractFromSection(category, currentPath);
        });
      }
    };
    
    assessment.sections.forEach(section => {
      extractFromSection(section);
    });
    
    return questions;
  },

  // Get question by ID
  getQuestionById: (assessment, questionId) => {
    const questions = QuestionParser.extractAllQuestions(assessment);
    return questions.find(q => q.id === questionId);
  },

  // Get all required questions
  getRequiredQuestions: (assessment) => {
    const questions = QuestionParser.extractAllQuestions(assessment);
    return questions.filter(q => q.required);
  }
};

export default checkList;
