const checkList = [
  {
    id: "01",
    departement: "DPAL",
    niveau: 6,
    sections: [
      {
        title: "Ressources humaines",
        subsections: [
          {
            title: "Le Site communautaire dispose-t-elle d'un :",
            questions: [
              {
                id: "rh_001",
                text: "Agent communautaire formé aux protocoles de prise en charge du paludisme",
                type: "simple",
                score: 1
              },
              {
                id: "rh_002",
                text: "AC formé en test de diagnostic rapide du paludisme",
                type: "simple",
                score: 1
              },
              {
                id: "rh_003",
                text: "AC formé sur la communication dans la lutte contre paludisme",
                type: "simple",
                score: 1
              },
              {
                id: "rh_004",
                text: "Est-ce que l'AC est en possession des documents cadres",
                type: "multiple",
                maxScore: 3,
                subQuestions: [
                  {
                    id: "rh_004_a",
                    text: "Ordonnogramme PEC",
                    score: 1
                  },
                  {
                    id: "rh_004_b",
                    text: "Job Aids",
                    score: 1
                  },
                  {
                    id: "rh_004_c",
                    text: "Affiches",
                    score: 1
                  }
                ]
              },
              {
                id: "rh_005",
                text: "Est-ce que l'AC est doté de matériels",
                type: "multiple",
                maxScore: 3,
                subQuestions: [
                  {
                    id: "rh_005_a",
                    text: "Tablette",
                    score: 1
                  },
                  {
                    id: "rh_005_b",
                    text: "Connexion internet",
                    score: 1
                  },
                  {
                    id: "rh_005_c",
                    text: "Crédit de communication",
                    score: 1
                  }
                ]
              },
              {
                id: "rh_006",
                text: "Est-ce que l'AC est encadré et supervisé par le Chef CSB et/ou AC relais",
                type: "simple"
              },
              {
                id: "rh_007",
                text: "Est-ce que l'AC participe à la revue mensuelle au niveau CSB",
                type: "simple"
              },
              {
                id: "rh_008",
                text: "Est-ce que l'AC relais fait des supervisions des AC",
                type: "multiple",
                subQuestions: [
                  "Planning de supervision",
                  "Rapport de supervision"
                ]
              }
            ]
          }
        ]
      },
      {
        title: "Prévention",
        subsections: [
          {
            title: "Utilisation MII",
            categories: [
              {
                name: "Accès et réception",
                questions: [
                  {
                    id: "mii_001",
                    text: "Avez-vous reçu des MII lors de la dernière distribution (campagne, routine ou urgence) ? Si oui, combien de MII?",
                    type: "simple"
                  },
                  {
                    id: "mii_002",
                    text: "Les MII que vous avez reçues ont-elles été distribuées gratuitement ? Si non, combien avez-vous payé ?",
                    type: "simple"
                  },
                  {
                    id: "mii_003",
                    text: "Utilisez-vous régulièrement votre MII pour dormir la nuit?",
                    type: "simple"
                  }
                ]
              },
              {
                name: "Qualité et utilisation",
                questions: [
                  {
                    id: "mii_004",
                    text: "Votre moustiquaire est-elle actuellement en bon état (pas de trou, propre, bien suspendue) ?",
                    type: "simple"
                  }
                ]
              },
              {
                name: "Sensibilisation et information",
                questions: [
                  {
                    id: "mii_005",
                    text: "Lors de la distribution, les agents communautaires vous ont-ils expliqué comment entretenir la MII ?",
                    type: "simple"
                  },
                  {
                    id: "mii_006",
                    text: "Avez-vous été informé par un agent communautaire sur la première utilisation des MII (ex. : aération avant usage) ?",
                    type: "simple"
                  },
                  {
                    id: "mii_007",
                    text: "Avez-vous reçu des informations sur l'entretien des MII (lavage, séchage, etc.) ? Si oui, par qui ?",
                    type: "simple"
                  }
                ]
              },
              {
                name: "Observations communautaires",
                questions: [
                  {
                    id: "mii_008",
                    text: "Avez-vous observé des problèmes lors de la distribution ou dans l'utilisation des MII dans votre communauté ? Si oui, précisez",
                    type: "simple"
                  },
                  {
                    id: "mii_009",
                    text: "Les membres de votre communauté utilisent-ils correctement les MII selon vous ?",
                    type: "simple"
                  }
                ]
              }
            ]
          },
          {
            title: "Application GIV",
            questions: [
              {
                id: "giv_001",
                text: "L'AC effectue-t-il des activités de sensibilisation au niveau de sa localité sur la nécessité de réalisation périodique du GIV",
                type: "simple"
              },
              {
                id: "giv_002",
                text: "L'AS est-il en mesure d'expliquer à la communauté ce qu'est la GIV et quels sont les activités à réaliser au cours de la GIV",
                type: "simple"
              },
              {
                id: "giv_003",
                text: "L'ASC est-il en mesure de convaincre sa communauté de réaliser la GIV de façon périodique",
                type: "simple"
              }
            ]
          },
          {
            title: "Pulvérisation intra-domicilaire",
            categories: [
              {
                name: "Agents pulvérisateurs",
                questions: [
                  {
                    id: "pulv_001",
                    text: "Avez-vous reçu une formation ? Si oui, sur quoi ?",
                    type: "simple"
                  },
                  {
                    id: "pulv_002",
                    text: "Combien de maisons pulvérisez-vous par jour en moyenne ?",
                    type: "simple"
                  },
                  {
                    id: "pulv_003",
                    text: "Rencontrez-vous des difficultés spécifiques ?",
                    type: "simple"
                  }
                ]
              },
              {
                name: "Ménages",
                questions: [
                  {
                    id: "pulv_004",
                    text: "Avez-vous été informé avant la pulvérisation ?",
                    type: "simple"
                  },
                  {
                    id: "pulv_005",
                    text: "Les agents ont-ils expliqué les consignes à suivre ?",
                    type: "simple"
                  },
                  {
                    id: "pulv_006",
                    text: "Avez-vous accepté la pulvérisation ? Si non, pourquoi ?",
                    type: "simple"
                  },
                  {
                    id: "pulv_007",
                    text: "Y a-t-il eu des effets secondaires après la pulvérisation ?",
                    type: "simple"
                  }
                ]
              }
            ]
          },
          {
            title: "TPI pour les femmes enceintes",
            questions: [
              {
                id: "tpi_001",
                text: "Les SP sont disponibles dans le centre et en quantité suffisante au niveau du site",
                type: "simple"
              },
              {
                id: "tpi_002",
                text: "L'agent communautaire/relais a été formé à l'administration du TPIg",
                type: "simple"
              },
              {
                id: "tpi_003",
                text: "Le TPIg est administré sous observation directe (DOT) même en communauté",
                type: "simple"
              },
              {
                id: "tpi_004",
                text: "Un délai d'au moins 1 mois entre deux doses est respecté",
                type: "simple"
              },
              {
                id: "tpi_005",
                text: "Les SP sont administrés à partir du 2è trimestre de grossesse",
                type: "simple"
              },
              {
                id: "tpi_006",
                text: "L'AC/relais conseille la femme enceinte sur les effets secondaires, les bénéfices, et le suivi à faire",
                type: "simple"
              },
              {
                id: "tpi_007",
                text: "Les femmes enceintes sont référées au centre de santé pour la 1re consultation CPN ou en cas de signes d'alerte",
                type: "simple"
              },
              {
                id: "tpi_008",
                text: "Le site communautaire est doté de supports d'éducation (affiches, flyers, audio, etc.)",
                type: "simple"
              }
            ]
          },
          {
            title: "Sensibilisation communautaire",
            questions: [
              {
                id: "sens_001",
                text: "Des activités de sensibilisation sont planifiées et effectivement réalisées",
                type: "simple"
              },
              {
                id: "sens_002",
                text: "Les messages diffusés sont conformes aux directives nationales (prévention, prise en charge, TPIg, AID, Consultation précoce, etc.)",
                type: "simple"
              },
              {
                id: "sens_003",
                text: "Les messages sont adaptés au niveau de compréhension de la population ciblée",
                type: "simple"
              },
              {
                id: "sens_004",
                text: "Les supports de communication sont disponibles (affiches, dépliants, mégaphones, radios locales, etc.)",
                type: "simple"
              },
              {
                id: "sens_005",
                text: "Des canaux variés sont utilisés (VAD, causeries, radio, groupes des femmes, leaders religieux)",
                type: "simple"
              },
              {
                id: "sens_006",
                text: "Les participants peuvent citer les messages clés après la séance",
                type: "simple"
              },
              {
                id: "sens_007",
                text: "Il y a un planning de communication et rapport",
                type: "simple"
              },
              {
                id: "sens_008",
                text: "Une fiche de présence ou un outil de suivi est utilisé pour chaque activité",
                type: "simple"
              },
              {
                id: "sens_009",
                text: "Des données sur les activités de sensibilisation sont compilées et remontées au centre de santé de référence",
                type: "simple"
              }
            ]
          }
        ]
      },
      {
        title: "Prise en Charge des Cas",
        questions: [
          {
            id: "pec_001",
            text: "Les tests de diagnostic rapide (RDT) sont disponibles",
            type: "multiple",
            subQuestions: [
              "Quantité correspondante aux besoins estimés",
              "Utilisés pour tester tous cas de fièvres"
            ]
          },
          {
            id: "pec_002",
            text: "Les ACT sont disponibles au niveau site",
            type: "multiple",
            subQuestions: [
              "À tout âge",
              "En quantité suffisante"
            ]
          },
          {
            id: "pec_003",
            text: "Artésunate suppo est disponible en cas de référence",
            type: "multiple",
            subQuestions: [
              "En quantité suffisante"
            ]
          },
          {
            id: "pec_004",
            text: "Aucun traitement antipaludique n'est administré sans confirmation par TDR",
            type: "simple"
          },
          {
            id: "pec_005",
            text: "Les résultats des TDR sont bien consignés dans les registres ou fiches de consultation",
            type: "simple"
          },
          {
            id: "pec_006",
            text: "Les cas graves sont correctement référés sans délai vers CSB",
            type: "simple"
          },
          {
            id: "pec_007",
            text: "Les posologies sont respectées (dose, durée, voie d'administration)",
            type: "simple"
          }
        ]
      },
      {
        title: "Surveillance épidémiologique et riposte",
        questions: [
          {
            id: "surv_001",
            text: "L'AC/AC relais sont formés à la détection des cas suspects de paludisme",
            type: "simple"
          },
          {
            id: "surv_002",
            text: "Un registre communautaire existe pour enregistrer les cas suspects ou confirmés",
            type: "simple"
          },
          {
            id: "surv_003",
            text: "L'AC /AC relais savent identifier les signes d'alerte ou de flambée (hausse inhabituelle de cas, décès suspects, etc.)",
            type: "simple"
          },
          {
            id: "surv_004",
            text: "Les cas suspects sont notifiés rapidement au CSB",
            type: "simple"
          },
          {
            id: "surv_005",
            text: "Des canaux de communication fonctionnels existent entre la communauté et le centre de santé (téléphone, visite, agent de liaison, etc.)",
            type: "simple"
          },
          {
            id: "surv_006",
            text: "En cas d'alerte, une enquête ou investigation communautaire est déclenchée avec le soutien du centre de santé",
            type: "simple"
          },
          {
            id: "surv_007",
            text: "Des actions de sensibilisation ou de prévention renforcées sont mises en place en cas d'alerte",
            type: "simple"
          },
          {
            id: "surv_008",
            text: "La communauté est impliquée activement dans le suivi de l'évolution de la situation (réunions, informations partagées, etc.)",
            type: "simple"
          },
          {
            id: "surv_009",
            text: "Les activités communautaires sont supervisées régulièrement par le centre de santé",
            type: "simple"
          },
          {
            id: "surv_010",
            text: "Des rapports ou fiches d'alerte sont archivés et disponibles",
            type: "simple"
          },
          {
            id: "surv_011",
            text: "Le relais / ASC connaît les mesures de riposte de première ligne (distribution de MII, intensification de la sensibilisation, etc.)",
            type: "simple"
          }
        ]
      },
      {
        title: "Gestion des Approvisionnements et Stock",
        questions: [
          {
            id: "stock_001",
            text: "Utilisez-vous des outils ou formulaires spécifiques pour passer les commandes ?",
            type: "simple"
          },
          {
            id: "stock_002",
            text: "Disposez-vous d'un registre de stock à jour (papier ou électronique) ?",
            type: "simple"
          },
          {
            id: "stock_003",
            text: "Avez-vous un système de gestion informatisé?",
            type: "simple"
          },
          {
            id: "stock_004",
            text: "Le registre de stock est-il mis à jour après chaque entrée/sortie de produits ?",
            type: "simple"
          },
          {
            id: "stock_005",
            text: "Quelle est la méthode de gestion des stocks utilisée ? (FIFO, FEFO, LIFO…)",
            type: "simple"
          },
          {
            id: "stock_006",
            text: "Faites-vous régulièrement l'inventaire physique des produits ? À quelle fréquence ?",
            type: "simple"
          },
          {
            id: "stock_007",
            text: "Observez-vous des écarts entre le stock physique et le stock théorique ? Si oui, à quelle fréquence ?",
            type: "simple"
          },
          {
            id: "stock_008",
            text: "Avez-vous un système d'alerte pour anticiper les ruptures de stock ?",
            type: "simple"
          },
          {
            id: "stock_009",
            text: "Avez-vous des pertes enregistrées ? Si oui, quelles en sont les causes principales ? (péremption, vol, mauvaise conservation...)",
            type: "simple"
          },
          {
            id: "stock_010",
            text: "Les conditions de stockage sont-elles conformes aux normes ? (aération, température, propreté, rangement…)",
            type: "simple"
          },
          {
            id: "stock_011",
            text: "Disposez-vous d'étagères adaptées et de palettes pour le rangement ?",
            type: "simple"
          },
          {
            id: "stock_012",
            text: "Y a-t-il des produits périmés dans les rayons ou entrepôts ?",
            type: "simple"
          },
          {
            id: "stock_013",
            text: "Avez-vous les documents suivants à jour : Fiches de stock, Bons de réception, Bons de sortie, Rapports d'inventaire",
            type: "multiple",
            subQuestions: [
              "Fiches de stock",
              "Bons de réception", 
              "Bons de sortie",
              "Rapports d'inventaire"
            ]
          },
          {
            id: "stock_014",
            text: "Conservez-vous une copie des documents de commande et de livraison ?",
            type: "simple"
          },
          {
            id: "stock_015",
            text: "Avez-vous un système formalisé pour la planification des commandes ?",
            type: "simple"
          },
          {
            id: "stock_016",
            text: "Avez-vous bénéficié d'une formation sur la gestion des stocks récemment ?",
            type: "simple"
          }
        ]
      }
    ]
  }
];

// Generate a model of questionnaire with sections, subsections, questions and subquestions
export default checkList;
