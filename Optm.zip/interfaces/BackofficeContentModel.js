// Backoffice Content Editing Interface Model
// This model is used for content management without scoring functionality

export const BackofficeContentModel = {
  // Assessment structure for content editing
  assessment: {
    id: String,
    departement: String,
    niveau: Number,
    title: String,
    description: String,
    sections: []
  },

  // Section structure
  section: {
    id: String,
    title: String,
    description: String,
    order: Number,
    subsections: [],
    questions: []
  },

  // Subsection structure
  subsection: {
    id: String,
    title: String,
    description: String,
    order: Number,
    categories: [],
    questions: []
  },

  // Category structure (for grouping questions)
  category: {
    id: String,
    name: String,
    description: String,
    order: Number,
    questions: []
  },

  // Question structure for content editing
  question: {
    id: String,
    text: String,
    description: String,
    type: String, // "simple" | "multiple" | "text" | "number"
    order: Number,
    required: Boolean,
    helpText: String,
    subQuestions: []
  },

  // Sub-question structure
  subQuestion: {
    id: String,
    text: String,
    description: String,
    order: Number,
    helpText: String
  }
};

// Content validation utilities
export const ContentValidator = {
  // Validate assessment structure
  validateAssessment: (assessment) => {
    const errors = [];
    
    if (!assessment.id) errors.push("Assessment ID is required");
    if (!assessment.title) errors.push("Assessment title is required");
    if (!assessment.departement) errors.push("Department is required");
    if (!assessment.sections || assessment.sections.length === 0) {
      errors.push("At least one section is required");
    }
    
    return {
      isValid: errors.length === 0,
      errors
    };
  },

  // Validate section structure
  validateSection: (section) => {
    const errors = [];
    
    if (!section.id) errors.push("Section ID is required");
    if (!section.title) errors.push("Section title is required");
    if (!section.questions && !section.subsections) {
      errors.push("Section must have either questions or subsections");
    }
    
    return {
      isValid: errors.length === 0,
      errors
    };
  },

  // Validate question structure
  validateQuestion: (question) => {
    const errors = [];
    
    if (!question.id) errors.push("Question ID is required");
    if (!question.text) errors.push("Question text is required");
    if (!["simple", "multiple", "text", "number"].includes(question.type)) {
      errors.push("Invalid question type");
    }
    
    if (question.type === "multiple" && (!question.subQuestions || question.subQuestions.length === 0)) {
      errors.push("Multiple choice questions must have sub-questions");
    }
    
    return {
      isValid: errors.length === 0,
      errors
    };
  }
};

// Content management utilities
export const ContentManager = {
  // Create new assessment
  createAssessment: (data) => {
    return {
      id: data.id || `assessment_${Date.now()}`,
      departement: data.departement || "",
      niveau: data.niveau || 0,
      title: data.title || "New Assessment",
      description: data.description || "",
      sections: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
  },

  // Create new section
  createSection: (data) => {
    return {
      id: data.id || `section_${Date.now()}`,
      title: data.title || "New Section",
      description: data.description || "",
      order: data.order || 0,
      subsections: [],
      questions: []
    };
  },

  // Create new question
  createQuestion: (data) => {
    return {
      id: data.id || `question_${Date.now()}`,
      text: data.text || "New Question",
      description: data.description || "",
      type: data.type || "simple",
      order: data.order || 0,
      required: data.required || false,
      helpText: data.helpText || "",
      subQuestions: data.type === "multiple" ? [] : undefined
    };
  },

  // Add question to section
  addQuestionToSection: (section, question) => {
    if (!section.questions) section.questions = [];
    question.order = section.questions.length;
    section.questions.push(question);
    return section;
  },

  // Remove question from section
  removeQuestionFromSection: (section, questionId) => {
    if (section.questions) {
      section.questions = section.questions.filter(q => q.id !== questionId);
      // Reorder remaining questions
      section.questions.forEach((q, index) => {
        q.order = index;
      });
    }
    return section;
  },

  // Reorder questions in section
  reorderQuestions: (section, questionIds) => {
    if (!section.questions) return section;
    
    const reorderedQuestions = [];
    questionIds.forEach((id, index) => {
      const question = section.questions.find(q => q.id === id);
      if (question) {
        question.order = index;
        reorderedQuestions.push(question);
      }
    });
    
    section.questions = reorderedQuestions;
    return section;
  },

  // Clone assessment for editing
  cloneAssessment: (assessment) => {
    return JSON.parse(JSON.stringify(assessment));
  },

  // Export assessment to JSON
  exportToJSON: (assessment) => {
    return JSON.stringify(assessment, null, 2);
  },

  // Import assessment from JSON
  importFromJSON: (jsonString) => {
    try {
      const assessment = JSON.parse(jsonString);
      const validation = ContentValidator.validateAssessment(assessment);
      
      if (!validation.isValid) {
        throw new Error(`Invalid assessment: ${validation.errors.join(", ")}`);
      }
      
      return assessment;
    } catch (error) {
      throw new Error(`Failed to import assessment: ${error.message}`);
    }
  }
};

// Search and filter utilities
export const ContentSearch = {
  // Search questions by text
  searchQuestions: (assessment, searchTerm) => {
    const allQuestions = [];
    
    const extractQuestions = (container, path = []) => {
      if (container.questions) {
        container.questions.forEach(question => {
          if (question.text.toLowerCase().includes(searchTerm.toLowerCase())) {
            allQuestions.push({
              ...question,
              path: [...path, container.title || container.name]
            });
          }
        });
      }
      
      if (container.sections) {
        container.sections.forEach(section => {
          extractQuestions(section, [...path, section.title]);
        });
      }
      
      if (container.subsections) {
        container.subsections.forEach(subsection => {
          extractQuestions(subsection, [...path, subsection.title]);
        });
      }
      
      if (container.categories) {
        container.categories.forEach(category => {
          extractQuestions(category, [...path, category.name]);
        });
      }
    };
    
    extractQuestions(assessment);
    return allQuestions;
  },

  // Filter questions by type
  filterQuestionsByType: (assessment, type) => {
    const allQuestions = [];
    
    const extractQuestions = (container) => {
      if (container.questions) {
        container.questions.forEach(question => {
          if (question.type === type) {
            allQuestions.push(question);
          }
        });
      }
      
      if (container.sections) {
        container.sections.forEach(section => extractQuestions(section));
      }
      
      if (container.subsections) {
        container.subsections.forEach(subsection => extractQuestions(subsection));
      }
      
      if (container.categories) {
        container.categories.forEach(category => extractQuestions(category));
      }
    };
    
    extractQuestions(assessment);
    return allQuestions;
  }
};

export default BackofficeContentModel;
