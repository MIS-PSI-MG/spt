// Quiz Interface Model
// This model is used for quiz functionality with scoring capabilities

export const QuizModel = {
  // Quiz session structure
  session: {
    id: String,
    assessmentId: String,
    userId: String,
    startTime: Date,
    endTime: Date,
    status: String, // "started" | "in_progress" | "completed" | "paused"
    currentQuestionId: String,
    responses: Object, // { questionId: response }
    scores: Object, // { sectionId: score }
    totalScore: Number,
    maxScore: Number,
    percentageScore: Number
  },

  // Question for quiz display
  quizQuestion: {
    id: String,
    text: String,
    type: String, // "simple" | "multiple"
    required: Boolean,
    helpText: String,
    maxScore: Number,
    sectionTitle: String,
    subsectionTitle: String,
    categoryName: String,
    order: Number,
    subQuestions: []
  },

  // Sub-question for quiz display
  quizSubQuestion: {
    id: String,
    text: String,
    maxScore: Number,
    order: Number
  },

  // Response structure
  response: {
    questionId: String,
    value: Boolean, // true | false | "NA"
    subResponses: Object, // { subQuestionId: Boolean }
    timestamp: Date,
    timeSpent: Number // seconds
  }
};

// Quiz session management
export const QuizSessionManager = {
  // Create new quiz session
  createSession: (assessmentId, userId) => {
    return {
      id: `session_${Date.now()}_${userId}`,
      assessmentId,
      userId,
      startTime: new Date(),
      endTime: null,
      status: "started",
      currentQuestionId: null,
      responses: {},
      scores: {},
      totalScore: 0,
      maxScore: 0,
      percentageScore: 0
    };
  },

  // Start quiz session
  startSession: (session, firstQuestionId) => {
    session.status = "in_progress";
    session.currentQuestionId = firstQuestionId;
    session.startTime = new Date();
    return session;
  },

  // Pause quiz session
  pauseSession: (session) => {
    session.status = "paused";
    return session;
  },

  // Resume quiz session
  resumeSession: (session) => {
    session.status = "in_progress";
    return session;
  },

  // Complete quiz session
  completeSession: (session) => {
    session.status = "completed";
    session.endTime = new Date();
    return session;
  },

  // Save response
  saveResponse: (session, questionId, response) => {
    session.responses[questionId] = {
      ...response,
      timestamp: new Date()
    };
    return session;
  },

  // Get session duration in minutes
  getSessionDuration: (session) => {
    if (!session.startTime) return 0;
    const endTime = session.endTime || new Date();
    return Math.round((endTime - session.startTime) / (1000 * 60));
  }
};

// Quiz navigation utilities
export const QuizNavigator = {
  // Get all questions in order
  getQuestionSequence: (assessment) => {
    const questions = [];
    
    const extractQuestions = (container, path = []) => {
      if (container.questions) {
        container.questions.forEach(question => {
          questions.push({
            ...question,
            sectionTitle: path[0] || "",
            subsectionTitle: path[1] || "",
            categoryName: path[2] || "",
            path: [...path]
          });
        });
      }
      
      if (container.sections) {
        container.sections.forEach(section => {
          extractQuestions(section, [section.title]);
        });
      }
      
      if (container.subsections) {
        container.subsections.forEach(subsection => {
          extractQuestions(subsection, [...path, subsection.title]);
        });
      }
      
      if (container.categories) {
        container.categories.forEach(category => {
          extractQuestions(category, [...path, category.name]);
        });
      }
    };
    
    extractQuestions(assessment);
    return questions.sort((a, b) => (a.order || 0) - (b.order || 0));
  },

  // Get next question
  getNextQuestion: (assessment, currentQuestionId) => {
    const questions = QuizNavigator.getQuestionSequence(assessment);
    const currentIndex = questions.findIndex(q => q.id === currentQuestionId);
    
    if (currentIndex === -1 || currentIndex === questions.length - 1) {
      return null; // No next question
    }
    
    return questions[currentIndex + 1];
  },

  // Get previous question
  getPreviousQuestion: (assessment, currentQuestionId) => {
    const questions = QuizNavigator.getQuestionSequence(assessment);
    const currentIndex = questions.findIndex(q => q.id === currentQuestionId);
    
    if (currentIndex <= 0) {
      return null; // No previous question
    }
    
    return questions[currentIndex - 1];
  },

  // Get question by ID
  getQuestionById: (assessment, questionId) => {
    const questions = QuizNavigator.getQuestionSequence(assessment);
    return questions.find(q => q.id === questionId);
  },

  // Get progress percentage
  getProgress: (assessment, currentQuestionId) => {
    const questions = QuizNavigator.getQuestionSequence(assessment);
    const currentIndex = questions.findIndex(q => q.id === currentQuestionId);
    
    if (currentIndex === -1) return 0;
    return Math.round(((currentIndex + 1) / questions.length) * 100);
  }
};

// Quiz scoring utilities
export const QuizScorer = {
  // Calculate question score
  calculateQuestionScore: (question, response) => {
    if (!response) return 0;
    
    if (question.type === "simple") {
      if (response.value === true) return question.maxScore;
      if (response.value === false) return 0;
      if (response.value === "NA") return 0; // or handle NA differently
      return 0;
    } else if (question.type === "multiple") {
      let score = 0;
      if (response.subResponses) {
        question.subQuestions.forEach(subQ => {
          if (response.subResponses[subQ.id] === true) {
            score += subQ.maxScore;
          }
        });
      }
      return score;
    }
    return 0;
  },

  // Calculate section score
  calculateSectionScore: (assessment, sectionId, responses) => {
    const questions = QuizNavigator.getQuestionSequence(assessment);
    const sectionQuestions = questions.filter(q => 
      q.path.some(p => p.includes(sectionId)) || q.sectionTitle.includes(sectionId)
    );
    
    return sectionQuestions.reduce((total, question) => {
      const response = responses[question.id];
      return total + QuizScorer.calculateQuestionScore(question, response);
    }, 0);
  },

  // Calculate total score
  calculateTotalScore: (assessment, responses) => {
    const questions = QuizNavigator.getQuestionSequence(assessment);
    
    return questions.reduce((total, question) => {
      const response = responses[question.id];
      return total + QuizScorer.calculateQuestionScore(question, response);
    }, 0);
  },

  // Calculate percentage score
  calculatePercentageScore: (assessment, responses) => {
    const totalScore = QuizScorer.calculateTotalScore(assessment, responses);
    const maxScore = assessment.maxScore || QuizScorer.calculateMaxScore(assessment);
    
    if (maxScore === 0) return 0;
    return Math.round((totalScore / maxScore) * 100);
  },

  // Calculate maximum possible score
  calculateMaxScore: (assessment) => {
    const questions = QuizNavigator.getQuestionSequence(assessment);
    
    return questions.reduce((total, question) => {
      if (question.type === "simple") {
        return total + question.maxScore;
      } else if (question.type === "multiple") {
        return total + question.subQuestions.reduce((subTotal, subQ) => {
          return subTotal + subQ.maxScore;
        }, 0);
      }
      return total;
    }, 0);
  },

  // Update session scores
  updateSessionScores: (session, assessment) => {
    session.totalScore = QuizScorer.calculateTotalScore(assessment, session.responses);
    session.maxScore = QuizScorer.calculateMaxScore(assessment);
    session.percentageScore = QuizScorer.calculatePercentageScore(assessment, session.responses);
    
    // Calculate section scores
    assessment.sections.forEach(section => {
      session.scores[section.id] = QuizScorer.calculateSectionScore(assessment, section.id, session.responses);
    });
    
    return session;
  }
};

// Quiz validation utilities
export const QuizValidator = {
  // Validate response
  validateResponse: (question, response) => {
    const errors = [];
    
    if (question.required && !response) {
      errors.push("Response is required for this question");
      return { isValid: false, errors };
    }
    
    if (question.type === "simple") {
      if (response.value !== true && response.value !== false && response.value !== "NA") {
        errors.push("Invalid response value for simple question");
      }
    } else if (question.type === "multiple") {
      if (!response.subResponses) {
        errors.push("Sub-responses are required for multiple choice questions");
      } else {
        question.subQuestions.forEach(subQ => {
          const subResponse = response.subResponses[subQ.id];
          if (subResponse !== true && subResponse !== false && subResponse !== "NA") {
            errors.push(`Invalid response for sub-question: ${subQ.text}`);
          }
        });
      }
    }
    
    return {
      isValid: errors.length === 0,
      errors
    };
  },

  // Check if quiz can be completed
  canCompleteQuiz: (assessment, responses) => {
    const questions = QuizNavigator.getQuestionSequence(assessment);
    const requiredQuestions = questions.filter(q => q.required);
    
    const missingResponses = requiredQuestions.filter(q => !responses[q.id]);
    
    return {
      canComplete: missingResponses.length === 0,
      missingQuestions: missingResponses
    };
  }
};

// Quiz results utilities
export const QuizResults = {
  // Generate results summary
  generateSummary: (session, assessment) => {
    const questions = QuizNavigator.getQuestionSequence(assessment);
    const answeredQuestions = questions.filter(q => session.responses[q.id]);
    const duration = QuizSessionManager.getSessionDuration(session);
    
    return {
      sessionId: session.id,
      assessmentTitle: assessment.title,
      totalQuestions: questions.length,
      answeredQuestions: answeredQuestions.length,
      totalScore: session.totalScore,
      maxScore: session.maxScore,
      percentageScore: session.percentageScore,
      duration: duration,
      completedAt: session.endTime,
      status: session.status
    };
  },

  // Generate detailed results
  generateDetailedResults: (session, assessment) => {
    const questions = QuizNavigator.getQuestionSequence(assessment);
    const results = [];
    
    questions.forEach(question => {
      const response = session.responses[question.id];
      const score = response ? QuizScorer.calculateQuestionScore(question, response) : 0;
      
      results.push({
        questionId: question.id,
        questionText: question.text,
        questionType: question.type,
        maxScore: question.maxScore,
        actualScore: score,
        response: response,
        sectionTitle: question.sectionTitle,
        subsectionTitle: question.subsectionTitle
      });
    });
    
    return results;
  },

  // Export results to CSV format
  exportToCSV: (session, assessment) => {
    const detailedResults = QuizResults.generateDetailedResults(session, assessment);
    const headers = ["Question ID", "Question Text", "Section", "Subsection", "Max Score", "Actual Score", "Response"];
    
    const rows = detailedResults.map(result => [
      result.questionId,
      `"${result.questionText}"`,
      result.sectionTitle,
      result.subsectionTitle,
      result.maxScore,
      result.actualScore,
      result.response ? JSON.stringify(result.response.value) : "No Response"
    ]);
    
    return [headers, ...rows].map(row => row.join(",")).join("\n");
  }
};

export default QuizModel;
